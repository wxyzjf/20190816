CREATE VIEW VW_PREORDER_REG_DETAILS (
    CASE_ID,
    STATUS,
    ORDER_DATE,
    ORDER_TIME,
    PROD_CD,
    PROD_GROUP,
    PROD_LONG_DESC,
    PROD_SHORT_DESC,
    SERIES,
    PRODUCT_NATURE,
    COLOR,
    PROD_DISPLAYORDER_1,
    PROD_DISPLAYORDER_2,
    REG_INV_NUM,
    REG_INV_DATE,
    REG_INV_TIME,
    POS_INV_NUM,
    POS_INV_DATE,
    POS_INV_TIME,
    PORDER_OVERDUE_GRACE_DAY,
    VOID_DATE,
    VOID_TIME,
    ORDER_CHANNEL,
    CUST_GROUP,
    PREPAID_IND,
    OVERDUE_DATE,
    HKID_BR,
    HSO_IND,
    ANY_COLOUR_IND,
    ORIGINAL_PRODUCT,
    ORG_PROD_GROUP,
    ORG_PROD_LONG_DESC,
    ORG_PROD_SHORT_DESC,
    ORG_SERIES,
    ORG_PRODUCT_NATURE,
    ORG_COLOR,
    ORG_PROD_DISPLAYORDER_1,
    ORG_PROD_DISPLAYORDER_2,
    CREATE_DATE,
    ORIGINAL_SUBMIT_DATE,
    CUST_NUM
) AS
SELECT a.CASE_ID,
       a.STATUS,
       a.ORDER_DATE,
       a.ORDER_TIME,
       a.PROD_CD,
       c.PROD_GROUP,
       c.PROD_LONG_DESC,
       c.PROD_SHORT_DESC,
       c.SERIES,
       c.PRODUCT_NATURE,
       c.COLOR,
       c.DISPLAYORDER_1 AS PROD_DISPLAYORDER_1,
       c.DISPLAYORDER_2 AS PROD_DISPLAYORDER_2,
       a.INV_NUM AS REG_INV_NUM,
       a.INV_DATE AS REG_INV_DATE,
       a.INV_TIME AS REG_INV_TIME,
       b.INV_NUM AS POS_INV_NUM,
       b.TRX_DATE AS POS_INV_DATE,
       b.TRX_TIME AS POS_INV_TIME,
       a.PORDER_OVERDUE_GRACE_DAY,
       a.VOID_DATE,
       a.VOID_TIME,
       a.ORDER_CHANNEL,
       a.CUST_GROUP,
       a.PREPAID_IND,
       a.OVERDUE_DATE,
       a.HKID_BR,
       a.HSO_IND,
       a.ANY_COLOUR_IND,
       a.ORIGINAL_PRODUCT,
       d.PROD_GROUP AS ORG_PROD_GROUP,
       d.PROD_LONG_DESC AS ORG_PROD_LONG_DESC,
       d.PROD_SHORT_DESC AS ORG_PROD_SHORT_DESC,
       d.SERIES AS ORG_SERIES,
       d.PRODUCT_NATURE AS ORG_PRODUCT_NATURE,
       d.COLOR AS ORG_COLOR,
       d.DISPLAYORDER_1 AS ORG_PROD_DISPLAYORDER_1,
       d.DISPLAYORDER_2 AS ORG_PROD_DISPLAYORDER_2,
       TO_DATE(a.CREATE_TS, 'YYYY-MM-DD') CREATE_DATE,
       a.ORIGINAL_SUBMIT_DATE,
       a.CUST_NUM
  FROM MIG_ADW.POS_IPHONE_REG a
  LEFT OUTER JOIN MIG_ADW.POS_RET_HDR_FM_2NOV b ON a.INV_NUM = b.INV_NUM AND TRX_DATE <= SYSDATE - 1
  LEFT OUTER JOIN (SELECT tmpa.PROD_CD,
                          tmpa.PROD_GROUP,
                          tmpa.PROD_LONG_DESC,
                          tmpa.PROD_SHORT_DESC,
                          tmpa.SERIES,
                          tmpa.PRODUCT_NATURE,
                          tmpa.COLOR,
                          tmpa.DISPLAYORDER_1,
                          tmpa.DISPLAYORDER_2
                     FROM MIG_ADW.PREORDER_PROD_REF tmpa
                    INNER JOIN (SELECT PROD_CD, MAX (EFF_END_DATE) EFF_END_DATE
                                  FROM MIG_ADW.PREORDER_PROD_REF
                                 GROUP BY PROD_CD) tmpb
                       ON tmpa.PROD_CD = tmpb.PROD_CD AND tmpa.EFF_END_DATE = tmpb.EFF_END_DATE
                    ) c ON a.PROD_CD = c.PROD_CD
  LEFT OUTER JOIN (SELECT tmpa.PROD_CD,
                          tmpa.PROD_GROUP,
                          tmpa.PROD_LONG_DESC,
                          tmpa.PROD_SHORT_DESC,
                          tmpa.SERIES,
                          tmpa.PRODUCT_NATURE,
                          tmpa.COLOR,
                          tmpa.DISPLAYORDER_1,
                          tmpa.DISPLAYORDER_2
                     FROM MIG_ADW.PREORDER_PROD_REF tmpa
                    INNER JOIN (SELECT PROD_CD, MAX (EFF_END_DATE) EFF_END_DATE
                                  FROM MIG_ADW.PREORDER_PROD_REF
                                 GROUP BY PROD_CD) tmpb
                            ON tmpa.PROD_CD = tmpb.PROD_CD AND tmpa.EFF_END_DATE = tmpb.EFF_END_DATE
                        ) d ON a.ORIGINAL_PRODUCT = d.PROD_CD
 WHERE a.ORIGINAL_SUBMIT_DATE <= SYSDATE - 1;
 
 
GRANT SELECT ON MIG_BIZ_SUMM.VW_PREORDER_REG_DETAILS TO MIG_ADW;

GRANT SELECT ON MIG_BIZ_SUMM.VW_PREORDER_REG_DETAILS TO ADWBAT_READ;
 
